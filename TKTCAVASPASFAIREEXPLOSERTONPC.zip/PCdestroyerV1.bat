@echo off
:loop
start C:\Windows\System32\diskmgmt.msc
goto loop